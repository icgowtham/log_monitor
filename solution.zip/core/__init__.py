"""Main application module."""
