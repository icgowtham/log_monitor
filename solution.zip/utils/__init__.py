"""Module for some utility functions."""
