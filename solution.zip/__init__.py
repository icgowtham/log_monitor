"""Log monitor module."""
